package httpapi

import (
	"errors"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"votely/internal/store"
)

const (
	maxTitleLength       = 160
	maxDescriptionLength = 2000
	maxOptionLength      = 300
	maxQuestionLength    = 500
)

type createPollRequest struct {
	Title            string   `json:"title"`
	Description      string   `json:"description"`
	Options          []string `json:"options"`
	IsAnonymous      bool     `json:"is_anonymous"`
	ShuffleOptions   bool     `json:"shuffle_options"`
	AllowedCountries []string `json:"allowed_countries"`
	EndsAt           string   `json:"ends_at"`
}

type createQuizRequest struct {
	Title            string                `json:"title"`
	Description      string                `json:"description"`
	Question         string                `json:"question"`
	Answers          []createQuizAnswerReq `json:"answers"`
	AllowedCountries []string              `json:"allowed_countries"`
	EndsAt           string                `json:"ends_at"`
}

type createQuizAnswerReq struct {
	Text      string `json:"text"`
	IsCorrect bool   `json:"is_correct"`
}

type votePollRequest struct {
	OptionID string `json:"option_id"`
}

func (r createPollRequest) toInput(ownerUserID int64, ownerKeyHash string) (store.PollInput, error) {
	title, err := validateText(r.Title, "Название опроса", maxTitleLength, true)
	if err != nil {
		return store.PollInput{}, err
	}
	if title == "" {
		return store.PollInput{}, errors.New("Укажите название опроса.")
	}
	description, err := validateText(r.Description, "Описание опроса", maxDescriptionLength, false)
	if err != nil {
		return store.PollInput{}, err
	}
	options, err := compactStrings(r.Options, maxOptionLength)
	if err != nil {
		return store.PollInput{}, err
	}
	if len(options) < 2 {
		return store.PollInput{}, errors.New("Добавьте минимум два варианта ответа.")
	}
	if len(options) > 20 {
		return store.PollInput{}, errors.New("В опросе может быть не больше 20 вариантов.")
	}
	allowedCountries, err := normalizeCountries(r.AllowedCountries)
	if err != nil {
		return store.PollInput{}, err
	}
	endsAt, err := parseEndsAt(r.EndsAt)
	if err != nil {
		return store.PollInput{}, err
	}
	return store.PollInput{
		Title:            title,
		Description:      description,
		Options:          options,
		OwnerUserID:      ownerUserID,
		OwnerKeyHash:     ownerKeyHash,
		IsAnonymous:      r.IsAnonymous,
		ShuffleOptions:   r.ShuffleOptions,
		AllowedCountries: allowedCountries,
		EndsAt:           endsAt,
	}, nil
}

func (r createQuizRequest) toInput(ownerUserID int64, ownerKeyHash string) (store.QuizInput, error) {
	title, err := validateText(r.Title, "Название викторины", maxTitleLength, true)
	if err != nil {
		return store.QuizInput{}, err
	}
	if title == "" {
		return store.QuizInput{}, errors.New("Укажите название викторины.")
	}
	description, err := validateText(r.Description, "Описание викторины", maxDescriptionLength, false)
	if err != nil {
		return store.QuizInput{}, err
	}
	questionText, err := validateText(r.Question, "Вопрос викторины", maxQuestionLength, true)
	if err != nil {
		return store.QuizInput{}, err
	}
	if questionText == "" {
		return store.QuizInput{}, errors.New("Заполните единственный вопрос викторины.")
	}
	if len(r.Answers) < 2 {
		return store.QuizInput{}, errors.New("Добавьте минимум два варианта ответа.")
	}

	answers := make([]store.QuizAnswerInput, 0, len(r.Answers))
	correctCount := 0
	for _, answer := range r.Answers {
		answerText, err := validateText(answer.Text, "Вариант ответа", maxOptionLength, true)
		if err != nil {
			return store.QuizInput{}, err
		}
		if answerText == "" {
			continue
		}
		if answer.IsCorrect {
			correctCount++
		}
		answers = append(answers, store.QuizAnswerInput{Text: answerText, IsCorrect: answer.IsCorrect})
	}
	if len(answers) < 2 {
		return store.QuizInput{}, errors.New("Добавьте минимум два заполненных варианта ответа.")
	}
	if len(answers) > 20 {
		return store.QuizInput{}, errors.New("В викторине может быть не больше 20 вариантов ответа.")
	}
	if correctCount != 1 {
		return store.QuizInput{}, errors.New("Отметьте ровно один правильный ответ.")
	}
	allowedCountries, err := normalizeCountries(r.AllowedCountries)
	if err != nil {
		return store.QuizInput{}, err
	}
	endsAt, err := parseEndsAt(r.EndsAt)
	if err != nil {
		return store.QuizInput{}, err
	}

	return store.QuizInput{
		Title:            title,
		Description:      description,
		OwnerUserID:      ownerUserID,
		OwnerKeyHash:     ownerKeyHash,
		AllowedCountries: allowedCountries,
		EndsAt:           endsAt,
		Questions: []store.QuizQuestionInput{{
			Text:    questionText,
			Answers: answers,
		}},
	}, nil
}

func compactStrings(values []string, maxLength int) ([]string, error) {
	result := make([]string, 0, len(values))
	for _, value := range values {
		trimmed, err := validateText(value, "Вариант ответа", maxLength, true)
		if err != nil {
			return nil, err
		}
		if trimmed != "" {
			result = append(result, trimmed)
		}
	}
	return result, nil
}

func validateText(value, field string, maxLength int, required bool) (string, error) {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		if required {
			return "", errors.New(field + " не может быть пустым.")
		}
		return "", nil
	}
	if !utf8.ValidString(trimmed) {
		return "", errors.New(field + " содержит некорректную кодировку.")
	}
	if utf8.RuneCountInString(trimmed) > maxLength {
		return "", errors.New(field + " слишком длинное.")
	}
	for _, r := range trimmed {
		if unicode.IsControl(r) && r != '\n' && r != '\r' && r != '\t' {
			return "", errors.New(field + " содержит недопустимые символы.")
		}
	}
	return trimmed, nil
}

func normalizeCountries(values []string) ([]string, error) {
	result := make([]string, 0, len(values))
	seen := make(map[string]struct{})
	for _, value := range values {
		code := strings.ToUpper(strings.TrimSpace(value))
		if code == "" {
			continue
		}
		if len(code) != 2 {
			return nil, errors.New("Код страны должен состоять из двух букв.")
		}
		for _, r := range code {
			if r < 'A' || r > 'Z' {
				return nil, errors.New("Код страны должен состоять из латинских букв.")
			}
		}
		if _, ok := seen[code]; ok {
			continue
		}
		seen[code] = struct{}{}
		result = append(result, code)
	}
	if len(result) > 30 {
		return nil, errors.New("Можно указать не больше 30 стран.")
	}
	return result, nil
}

func parseEndsAt(value string) (*time.Time, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return nil, nil
	}
	parsed, err := time.Parse(time.RFC3339, value)
	if err != nil {
		return nil, errors.New("Укажите время окончания в ISO-формате.")
	}
	if parsed.Before(time.Now().Add(time.Minute)) {
		return nil, errors.New("Время окончания должно быть в будущем.")
	}
	return &parsed, nil
}
